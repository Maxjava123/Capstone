import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/user_model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<bool> register(String email, String password, String role,
      {String? teacherKey, String? studentID}) async {
    try {
      if (role == 'Teacher' && teacherKey != '1234') {
        throw Exception("Invalid teacher key.");
      }
      UserCredential result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      User? user = result.user;

      UserModel newUser = UserModel(uid: user!.uid, email: email, role: role);

      await _firestore.collection('users').doc(user.uid).set(newUser.toMap());

      return true;
    } catch (e) {
      print(e.toString());
      return false;
    }
  }

  Future<UserModel?> login(String email, String password) async {
    try {
      print('Attempting to log in with email: $email');
      UserCredential result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      User? user = result.user;

      if (user != null) {
        DocumentSnapshot doc =
            await _firestore.collection('users').doc(user.uid).get();
        print('Login successful. User UID: ${user.uid}');
        return UserModel.fromMap(doc.data() as Map<String, dynamic>, user.uid);
      } else {
        print('Login failed: User is null.');
        return null;
      }
    } catch (e) {
      print('Login failed with error: ${e.toString()}');
      return null;
    }
  }

  Future<bool> signOut() async {
    try {
      await _auth.signOut();
      return true;
    } catch (e) {
      print(e.toString());
      return false;
    }
  }

  Future<UserModel?> getUserDetails(String uid) async {
    try {
      DocumentSnapshot doc =
          await _firestore.collection('users').doc(uid).get();
      return UserModel.fromMap(doc.data() as Map<String, dynamic>, uid);
    } catch (e) {
      print(e.toString());
      return null;
    }
  }
}
