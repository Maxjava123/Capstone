class UserModel {
  final String uid;
  final String email;
  final String role;

  UserModel({required this.uid, required this.email, required this.role});

  // Create a UserModel object from a Firestore document snapshot
  factory UserModel.fromMap(Map<String, dynamic> data, String uid) {
    return UserModel(
      uid: uid,
      email: data['email'] ?? '',
      role: data['role'] ?? '',
    );
  }

  // Convert UserModel object to a map for storing in Firestore
  Map<String, dynamic> toMap() {
    return {
      'email': email,
      'role': role,
    };
  }
}
