import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import 'login_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final AuthService _authService = AuthService();
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String password = '';
  String role = 'Student';
  String? teacherKey;
  String? studentID;

  void _showPopup(String message, {bool isSuccess = true}) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(isSuccess ? 'Success' : 'Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                if (isSuccess) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                  );
                }
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (val) => val!.isEmpty ? 'Enter an email' : null,
                onChanged: (val) => setState(() => email = val),
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (val) =>
                    val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                onChanged: (val) => setState(() => password = val),
              ),
              DropdownButtonFormField<String>(
                value: role,
                items: ['Teacher', 'Student', 'Parent'].map((String role) {
                  return DropdownMenuItem<String>(
                    value: role,
                    child: Text(role),
                  );
                }).toList(),
                onChanged: (val) => setState(() => role = val!),
                decoration: const InputDecoration(labelText: 'Role'),
              ),
              if (role == 'Teacher')
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Teacher Key'),
                  validator: (val) =>
                      val != '1234' ? 'Invalid teacher key' : null,
                  onChanged: (val) => setState(() => teacherKey = val),
                ),
              if (role == 'Student')
                TextFormField(
                  decoration: const InputDecoration(labelText: 'Student ID'),
                  validator: (val) =>
                      val!.isEmpty ? 'Enter a student ID' : null,
                  onChanged: (val) => setState(() => studentID = val),
                ),
              ElevatedButton(
                child: const Text('Register'),
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    bool success = await _authService.register(
                        email, password, role,
                        teacherKey: teacherKey, studentID: studentID);
                    if (success) {
                      _showPopup('Registration successful! Please log in.', 
                          isSuccess: true);
                    } else {
                      _showPopup('Registration failed. Please try again.',
                          isSuccess: false);
                    }
                  }
                },
              ),
              const SizedBox(height: 20),
              TextButton(
                child: const Text('Already have an account? Login here'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const LoginScreen()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
