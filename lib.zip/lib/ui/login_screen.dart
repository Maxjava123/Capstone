import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import 'parent_screen.dart';
import 'register_screen.dart';
import 'student_screen.dart';
import 'teacher_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final AuthService _authService = AuthService();
  final _formKey = GlobalKey<FormState>();
  String email = '';
  String password = '';
  bool _isLoading = false;

  void _navigateToRoleScreen(String role) {
    Widget targetScreen;
    switch (role) {
      case 'Student':
        targetScreen = const StudentScreen();
        break;
      case 'Parent':
        targetScreen = const ParentScreen();
        break;
      case 'Teacher':
        targetScreen = const TeacherScreen();
        break;
      default:
        targetScreen = const Center(child: Text('Unknown role'));
    }
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => targetScreen),
    );
  }

  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true; // Show loading spinner
      });

      var user = await _authService.login(email, password);

      setState(() {
        _isLoading = false; // Hide loading spinner
      });

      if (user != null) {
        // Directly navigate to the role screen
        _navigateToRoleScreen(user.role);
      } else {
        _showErrorDialog('Login failed. Please try again.');
      }
    } else {
      print('Form validation failed.');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss dialog
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login')),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              TextFormField(
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (val) => val!.isEmpty ? 'Enter an email' : null,
                onChanged: (val) => setState(() => email = val),
              ),
              TextFormField(
                decoration: const InputDecoration(labelText: 'Password'),
                obscureText: true,
                validator: (val) =>
                    val!.length < 6 ? 'Enter a password 6+ chars long' : null,
                onChanged: (val) => setState(() => password = val),
              ),
              const SizedBox(height: 20),
              _isLoading
                  ? const CircularProgressIndicator() // Show loading indicator
                  : ElevatedButton(
                      child: const Text('Login'),
                      onPressed: _login,
                    ),
              const SizedBox(height: 20),
              TextButton(
                child: const Text('Don\'t have an account? Register here'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => RegisterScreen()),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
